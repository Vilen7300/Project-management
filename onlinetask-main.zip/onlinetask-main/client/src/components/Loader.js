import React from 'react';

function Loader() {
  return (
    <div className='loader-parent h-100'>
      <div className='loader'></div>
    </div>
  )
}

export default Loader